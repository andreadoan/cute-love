import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useCreateResponse } from "@/hooks/use-responses";
import { FloatingHearts } from "@/components/FloatingHearts";
import { CuteCharacter } from "@/components/CuteCharacter";
import { Heart } from "lucide-react";

export default function Home() {
  const [isAccepted, setIsAccepted] = useState(false);
  const [noPosition, setNoPosition] = useState<{ x: number | null, y: number | null }>({ x: null, y: null });
  const { mutate: createResponse, isPending } = useCreateResponse();
  const containerRef = useRef<HTMLDivElement>(null);

  // Audio object initialization
  const audioRef = useRef<HTMLAudioElement | null>(null);
  
  useEffect(() => {
    // Preload the music
    audioRef.current = new Audio("https://cdn.pixabay.com/download/audio/2022/05/27/audio_1808fbf07a.mp3");
    audioRef.current.loop = true;
  }, []);

  const handleYesClick = () => {
    createResponse({ message: "Yes" });
    setIsAccepted(true);
    
    // Play romantic music
    if (audioRef.current) {
      audioRef.current.play().catch(e => {
        console.error("Audio playback failed due to browser restrictions:", e);
      });
    }
  };

  const handleNoInteraction = () => {
    // Only run if we are not accepted
    if (isAccepted) return;

    // Calculate a random position for the "No" button
    // Ensure it stays within viewport boundaries
    const buttonWidth = 100;
    const buttonHeight = 60;
    const padding = 20;

    const maxX = window.innerWidth - buttonWidth - padding;
    const maxY = window.innerHeight - buttonHeight - padding;

    const randomX = Math.max(padding, Math.floor(Math.random() * maxX));
    const randomY = Math.max(padding, Math.floor(Math.random() * maxY));

    setNoPosition({ x: randomX, y: randomY });
  };

  return (
    <main className="min-h-screen flex items-center justify-center p-4 overflow-hidden relative">
      <AnimatePresence mode="wait">
        {!isAccepted ? (
          <motion.div
            key="question-screen"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 1.1, filter: "blur(10px)" }}
            transition={{ duration: 0.5 }}
            className="glass-card rounded-[2.5rem] p-8 md:p-12 max-w-lg w-full text-center relative z-10"
            ref={containerRef}
          >
            <CuteCharacter />
            
            <motion.h1 
              className="text-4xl md:text-5xl lg:text-6xl font-display text-rose-500 mb-10 leading-tight"
              animate={{ scale: [1, 1.02, 1] }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              Will you always love me? 💗
            </motion.h1>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-6 mt-8 min-h-[80px]">
              <motion.button
                onClick={handleYesClick}
                disabled={isPending}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-10 py-4 rounded-full bg-gradient-to-r from-rose-400 to-pink-500 text-white font-bold text-xl md:text-2xl shadow-lg shadow-pink-300/50 hover:shadow-pink-400/60 transition-all z-20 disabled:opacity-50"
              >
                {isPending ? "Waiting..." : "Yes! 🥰"}
              </motion.button>

              <motion.button
                onMouseEnter={handleNoInteraction}
                onTouchStart={handleNoInteraction}
                onClick={handleNoInteraction}
                style={
                  noPosition.x !== null 
                    ? { position: 'fixed', left: noPosition.x, top: noPosition.y, zIndex: 50 } 
                    : { position: 'relative' }
                }
                animate={noPosition.x !== null ? { x: 0, y: 0 } : {}}
                transition={{ type: "spring", stiffness: 300, damping: 20 }}
                className="px-10 py-4 rounded-full bg-slate-100 text-slate-500 font-bold text-xl md:text-2xl shadow-sm hover:bg-slate-200 transition-colors"
              >
                No 😢
              </motion.button>
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="success-screen"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, type: "spring", bounce: 0.5 }}
            className="glass-card rounded-[3rem] p-10 md:p-16 max-w-xl w-full text-center relative z-10 border-4 border-white/60"
          >
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1, rotate: [-10, 10, -10] }}
              transition={{ 
                scale: { type: "spring", delay: 0.2 }, 
                rotate: { duration: 2, repeat: Infinity, ease: "easeInOut" } 
              }}
              className="flex justify-center mb-6"
            >
              <div className="relative">
                <Heart className="w-32 h-32 text-rose-500 fill-rose-500 drop-shadow-xl" />
                <Heart className="w-16 h-16 text-pink-300 fill-pink-300 absolute -top-4 -right-4 animate-ping" />
              </div>
            </motion.div>
            
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="text-4xl md:text-6xl font-display text-rose-600 mb-6 leading-tight"
            >
              Yay! I knew it, baby 💕
            </motion.h2>
            
            <motion.p 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1 }}
              className="text-2xl md:text-3xl text-rose-400 font-medium leading-relaxed"
            >
              So, You’re stuck with me now 😘.<br/>
              <span className="block mt-4 text-3xl md:text-4xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-rose-500 to-pink-500 drop-shadow-sm">
                I Love you 💖
              </span>
            </motion.p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Render floating hearts only on success screen */}
      {isAccepted && <FloatingHearts />}
    </main>
  );
}
