import { motion } from "framer-motion";

export function CuteCharacter() {
  return (
    <motion.div 
      className="relative w-48 h-48 mx-auto my-6 select-none"
      animate={{ 
        y: [0, -10, 0],
      }}
      transition={{ 
        duration: 2, 
        repeat: Infinity, 
        ease: "easeInOut" 
      }}
    >
      {/* Ears */}
      <motion.div 
        className="absolute top-2 left-2 w-14 h-14 bg-white rounded-full border-[5px] border-rose-200 z-0"
        animate={{ rotate: [-5, 5, -5] }}
        transition={{ duration: 4, repeat: Infinity }}
      />
      <motion.div 
        className="absolute top-2 right-2 w-14 h-14 bg-white rounded-full border-[5px] border-rose-200 z-0"
        animate={{ rotate: [5, -5, 5] }}
        transition={{ duration: 4, repeat: Infinity }}
      />
      
      {/* Head */}
      <div className="absolute inset-4 bg-white rounded-full border-[5px] border-rose-200 shadow-inner z-10 overflow-hidden">
        {/* Inner shadow/highlight for depth */}
        <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-rose-50/50 to-transparent"></div>
        
        {/* Eyes */}
        <div className="absolute top-16 left-8 w-3 h-5 bg-slate-700 rounded-full">
          {/* Eye shine */}
          <div className="absolute top-0.5 right-0.5 w-1 h-1.5 bg-white rounded-full"></div>
        </div>
        <div className="absolute top-16 right-8 w-3 h-5 bg-slate-700 rounded-full">
           {/* Eye shine */}
           <div className="absolute top-0.5 right-0.5 w-1 h-1.5 bg-white rounded-full"></div>
        </div>
        
        {/* Blush */}
        <motion.div 
          className="absolute top-20 left-3 w-8 h-4 bg-rose-300 rounded-full blur-[2px] opacity-70"
          animate={{ opacity: [0.5, 0.8, 0.5] }}
          transition={{ duration: 2, repeat: Infinity }}
        />
        <motion.div 
          className="absolute top-20 right-3 w-8 h-4 bg-rose-300 rounded-full blur-[2px] opacity-70"
          animate={{ opacity: [0.5, 0.8, 0.5] }}
          transition={{ duration: 2, repeat: Infinity }}
        />
        
        {/* Mouth (cute 'w') */}
        <svg 
          className="absolute top-18 left-1/2 -translate-x-1/2 w-8 h-4 text-slate-700" 
          viewBox="0 0 24 12" 
          fill="none" 
          stroke="currentColor" 
          strokeWidth="3.5" 
          strokeLinecap="round" 
          strokeLinejoin="round"
        >
          <path d="M2 2 Q6 10 12 2 Q18 10 22 2" />
        </svg>

        {/* Tiny nose */}
        <div className="absolute top-17 left-1/2 -translate-x-1/2 w-2 h-1.5 bg-rose-300 rounded-full"></div>
      </div>

      {/* Floating Mini Hearts */}
      <motion.div 
        className="absolute -top-4 -right-4 text-rose-400 text-2xl z-20"
        animate={{ y: [0, -15], opacity: [1, 0], scale: [1, 1.2] }}
        transition={{ duration: 1.5, repeat: Infinity, delay: 0 }}
      >
        💖
      </motion.div>
      <motion.div 
        className="absolute top-10 -left-6 text-pink-400 text-xl z-20"
        animate={{ y: [0, -15], opacity: [1, 0], scale: [1, 1.2] }}
        transition={{ duration: 1.5, repeat: Infinity, delay: 0.7 }}
      >
        💕
      </motion.div>
    </motion.div>
  );
}
