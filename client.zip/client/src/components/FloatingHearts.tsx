import { motion } from "framer-motion";
import { Heart } from "lucide-react";
import { useEffect, useState } from "react";

interface Particle {
  id: number;
  x: number;
  size: number;
  duration: number;
  delay: number;
}

export function FloatingHearts() {
  const [particles, setParticles] = useState<Particle[]>([]);

  useEffect(() => {
    // Generate random hearts across the screen
    const newParticles = Array.from({ length: 40 }).map((_, i) => ({
      id: i,
      x: Math.random() * 100, // percentage of screen width
      size: Math.random() * 20 + 15, // size between 15 and 35px
      duration: Math.random() * 4 + 3, // 3 to 7 seconds to float up
      delay: Math.random() * 2, // 0 to 2 seconds delay
    }));
    setParticles(newParticles);
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-50">
      {particles.map((p) => (
        <motion.div
          key={p.id}
          initial={{ 
            opacity: 0, 
            y: "100vh", 
            x: `${p.x}vw`,
            scale: 0,
            rotate: 0 
          }}
          animate={{ 
            opacity: [0, 1, 0.8, 0], 
            y: "-10vh",
            x: [`${p.x}vw`, `${p.x - 5}vw`, `${p.x + 5}vw`, `${p.x}vw`],
            scale: [0, 1, 1.2, 1],
            rotate: [0, 15, -15, 0]
          }}
          transition={{
            duration: p.duration,
            delay: p.delay,
            ease: "easeOut",
            repeat: Infinity,
          }}
          className="absolute text-pink-400 drop-shadow-md"
          style={{ width: p.size, height: p.size }}
        >
          <Heart size={p.size} fill="currentColor" />
        </motion.div>
      ))}
    </div>
  );
}
